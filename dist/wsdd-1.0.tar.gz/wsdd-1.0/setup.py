from distutils.core import setup
setup(name='wsdd',
      version='1.0',
      packages=['wsdd'],
      package_dir={'wsdd': 'src'},
      author='Steffen Christgau',
      url='https://github.com/freenas/wsdd'
      )
