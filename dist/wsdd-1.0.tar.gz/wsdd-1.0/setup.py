from distutils.core import setup
setup(name='wsdd',
      version='1.0',
      packages=['wsdd'],
      package_dir={'wsdd': 'src'},
      author='Andrew Walker',
      author_email='awalker@ixsystems.com',
      url='https://github.com/anodos325/wsdd'
      )
